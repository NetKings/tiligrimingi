#[SuperGroup Source](https://github.com/allwenwaker/SuperGroup)
*A Source For Your SuperGroup Bot *

_Put Your Id In bot/SuperGroup.lua_

#[Change SuperGroup.lua Name](https://github.com/AllwenWaker/SuperGroup/blob/supergroups/bot/SuperGroup.lua)
*When You Change This File Name , You Need Edit launch.sh !*

#[Change plugins/supergroup.lua](https://github.com/AllwenWaker/SuperGroup/blob/supergroups/plugins/supergroup.lua)
*You Can Edit Setting Massages !*





#[Installation The Bot](https://telegram.me/antispam_api_bot)
In Linux & Other Servers 

git clone https://github.com/allwenwaker/SuperGroup

cd SuperGroup

./launch.sh install

./launch.sh

In Free Servers To [C9](https://c9.io) Or [Koding](https://koding.com)


